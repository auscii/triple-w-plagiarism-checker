var config = {
    apiKey: "AIzaSyA9_IbfJ_xbhOs_8w88d4C59PDdLfbGvSQ",
    authDomain: "triple-w.firebaseapp.com",
    databaseURL: "https://triple-w.firebaseio.com",
    projectId: "triple-w",
    storageBucket: "triple-w.appspot.com",
    messagingSenderId: "234149438631",
    appId: "1:234149438631:web:8d681c302fc8ff61746782"
};
firebase.initializeApp(config);
var database = firebase.database();