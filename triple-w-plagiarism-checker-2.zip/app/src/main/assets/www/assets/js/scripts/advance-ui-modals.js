/*
* Modals - Advanced UI
*/
$(function() {
    $('.modal').modal();
    $('#modal1').modal('open');
    $('#modal3').modal('open');
    $('#modal3').modal('close');
  });